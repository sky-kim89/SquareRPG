using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
public class UICardItem : MonoBehaviour
{
    [SerializeField]
    private Image m_Icon = null;
    
    public void Init(CardData card)
    {
        m_Icon.sprite = UIManager.Instance.GetSprite(card.Image);
    }

    public void OnClick()
    {
    }
}
