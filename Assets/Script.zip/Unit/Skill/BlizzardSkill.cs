using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlizzardSkill : ActiveSkill
{
    public BlizzardSkill()
    {
        Data = new SkillData();
        Data.Name = "Blizzard";
        Data.Icon = "Blizzard";
        Data.ActiveEffectIndex = -1;
        Data.TargetEffectIndex = 7;
        Data.Description = "������ �̸��� ���� ������ ������ {0}%�� ���ظ� �ش�";
        Data.MaxCoolTime = 33;
        Data.Knockback = 0.2f;
        Data.SkillType = eSkillType.Active;
        Data.Animation = "Skill";
        Data.Value = 0.4f;
        Data.WeaponType = eWeaponType.Wand;
    }
    public override void Active(Unit unit, Unit target)
    {
        Unit = unit;
        Target = target;
        if (Data.Animation != string.Empty)
            unit.PlayAnimation(Data.Animation);

        SkillEffect skillEffect = SkillManager.Instance.GetSkillEffect<SkillEffect>(Data.TargetEffectIndex);
        skillEffect.Init(target, GetSkillDamage(unit));
        skillEffect.transform.position = target.transform.position;

        CoolTime = Data.MaxCoolTime;
    }
}
