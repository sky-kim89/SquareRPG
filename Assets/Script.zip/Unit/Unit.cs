using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEditor;

public enum eUnitStateType
{
    None = -1,
    Attack = 0,
    Hit = 1,
    Move = 3,
    Kill = 5,
    Start = 6,
    Skilling = 7,
    Attacking = 8,
    Hiting = 11,
    Die = 12,
    Dieing = 13,
    //���� �� ���� �̻� �߰� �ʿ�
}
public enum eGradeType
{
    Common = 1,
    UnCommon = 2,
    Rare = 3,
    Unique = 4,
    Epic = 5,

    Last = 6
}

//������ ��� ���� ��ų�� ���� ����.
public enum eWeaponType
{
    Sword,
    Shield,
    Dagger,
    Bow,
    Wand,
    Last,

    ALL
}

public enum eTargetType
{
    Hero,
    Minion,
    Boss,

    All
}

public class HeroSaveData
{
    public string Name = string.Empty;
    public int AddLevel = 1; //��ȭ ����
    public int UpGrade = 0;  //��ȭ ���
    public int AddUnitCount = 0; //�߰� ���� ��

    //���� ����
    //���� ������
    //���� ��ġ ����
}

[System.Serializable]
public class  UnitData
{
    //public eAttackType AttackType = eAttackType.Normal;
    //public eJobType JobType = eJobType.Warrior;
    //public eSizeType Size = eSizeType.Middle;
    public eGradeType Grade = eGradeType.Common;
    public eWeaponType Weapon = eWeaponType.Sword;

    public string Name = string.Empty;

    public float AP = 1; //�Ϲ� ����
    public float HP = 1; //ü��
    public float SP = 1; //��ų ����
    public float LP = 1; //������ (���� ����)

    public float Attack { get { return AP * GameManager.Instance.Ap * (1f + Level * GameManager.Instance.Level); } }
    public float Health { get { return HP * GameManager.Instance.Hp * (1f + Level * GameManager.Instance.Level); } }

    public int Level = 1; //����

    public int AddLevel = 0;
    public int UpGrade = 0;
    public int AddUnitCount = 0;

    public int UnitCount { get { return (int)(LP * 0.5f) + AddUnitCount; } }

    public float DamageRate = 1.0f;
    public float SkillDamageRate = 1.0f;
    public int Exp = 0;

    public float AttackRange = 1.5f;
    public float AttackSpeed = 1.0f;
    public float MoveSpeed = 1;
    public float SkillCoolTime = 1;
    public float DamageReduction = 0;


    public AttackSkill AttackSkill = null; // ��Ÿ
    public Skill[] Skills = new Skill[4];
    public Color[] UnitColors = new Color[5];

    public int OpenSkill = 1;

    public UnitData HalfData()
    {
        UnitData data = new UnitData();

        float def = GameManager.Instance.LP_def;
        float addLp = GameManager.Instance.Lp;
        data.Name = Name;

        data.AP = AP * (def + LP * addLp);
        data.SP = SP * (def + LP * addLp);
        data.HP = HP * (def + LP * addLp);
        data.LP = LP * (def + LP * addLp);

        data.DamageRate = DamageRate * (def + LP * addLp);
        data.Grade = Grade;
        data.Level = Level;
        data.AddLevel = AddLevel;

        data.AttackRange = AttackRange * 0.9f;
        data.AttackSpeed = AttackSpeed;
        data.UnitColors = UnitColors;
        data.Weapon = Weapon;
        data.MoveSpeed = MoveSpeed;
        data.AttackSkill = AttackSkill;
        return data;
    }

    public HeroSaveData GetSaveData()
    {
        HeroSaveData data = new HeroSaveData();
        data.Name = Name;
        data.AddLevel = AddLevel;
        data.UpGrade = UpGrade;
        data.AddUnitCount = AddUnitCount;

        return data;
    }

    public void Restore()
    {
        Skills[0].CoolTime = 0;
    }
}
//��ų�� ���� �⺻ ���� = ����
public class Unit : MonoBehaviour
{
    public HeroUnit Hero = null;

    [SerializeField]
    protected UnitStateUI m_StateUI = null;
    [SerializeField]
    protected Animator m_Animator = null;
    [SerializeField]
    protected GameObject m_RootObj = null;
    [SerializeField]
    protected UnitColoring m_UnitColoring = null;
    [SerializeField]
    protected List<GameObject> m_WeaponObjs = new List<GameObject>();
    [SerializeField]
    protected List<GameObject> m_ArrowObjs = new List<GameObject>();

    [SerializeField]
    public UnitData UnitData = null;

    [SerializeField]
    public UnitData m_BuffUnitData = null;

    protected Dictionary<eUnitStateType, Action> StateCoolBack = new Dictionary<eUnitStateType, Action>();

    [SerializeField]
    protected eUnitStateType m_UnitState = eUnitStateType.None;
    public eUnitStateType UnitState
    { 
        get
        { return m_UnitState; }
        set
        {
            if (m_UnitState != value)
            {
                m_UnitState = value;
                if (StateCoolBack.ContainsKey(value))
                    StateCoolBack[value]();

                ApplyBuff();
            }

        }
    }

    public eTargetType UnitType = eTargetType.Minion;
    public bool IsDie { get { return m_UnitState == eUnitStateType.Die || m_UnitState == eUnitStateType.Dieing; } }

    [SerializeField]
    protected List<BuffData> m_Buffs = new List<BuffData>();

    [SerializeField]
    protected Unit m_Target = null;

    public int TotalLevel { get { return UnitData.Level + UnitData.AddLevel; } }
    public float AP = 0;
    public float HP = 0;
    public float MaxHP = 0;

    public float GetHpRatio { get { return HP / MaxHP; } }

    public float DamageRate = 0;
    public float SkillDamageRate { get { return m_BuffUnitData.SP * GameManager.Instance.Sp * m_BuffUnitData.SkillDamageRate; } }

    public bool isEnemy = false;

    public AttackSkill AttackSkill = null; // ��Ÿ
    [SerializeField]
    public List<Skill> SkillList = new List<Skill>();

    public SaveDamageStats SaveDamageStats = new SaveDamageStats();
    public int OpneSkill = 0;

    public virtual void Init(UnitData data, bool enemy)
    {
        UnitData = data; 
        UnitType = eTargetType.Minion;
        m_UnitState = eUnitStateType.None;
        UnitState = eUnitStateType.Start;
        m_Buffs.Clear();
        StateCoolBack.Clear();
        SaveDamageStats.ReSet();
        SetStatus();
        InitSkill();
        BuffDataUpdate();

        for (int i = 0; i < m_WeaponObjs.Count; i++)
        {
            m_WeaponObjs[i].SetActive(false);
        }
        
        m_WeaponObjs[(int)data.Weapon].SetActive(true);

        m_UnitColoring.ChangeColor(data.UnitColors);

        m_RootObj.SetActive(true);
        gameObject.EnableCollider();

        isEnemy = enemy;
        m_StateUI.SetEnemy(isEnemy);
        m_StateUI.ReSet();

        float delay = UnityEngine.Random.Range(0.5f, 0.7f);
        InvokeRepeating("FindTarget", 0, delay);
    }

    private void FindTarget()
    {
        m_Target = UnitManager.Instance.FindUnit(this);
    }

    private void InitSkill()
    {
        AttackSkill = UnitData.AttackSkill;
        SkillList.Clear();
        SkillList.AddRange(UnitData.Skills);

        for(int i = 0; i < SkillList.Count; i++)
        {
            if (SkillList[i] is PassiveSkill && UnitData.OpenSkill > OpneSkill)
            {
                OpneSkill++;
                m_Buffs.Add((SkillList[i] as PassiveSkill).Buff.Clone());
            }
        }
    }

    private void BuffDataUpdate()
    {
        m_BuffUnitData = new UnitData();
        float AP = 1 + m_Buffs.GetBuffTypeToValue(this, eBuffType.AP);
        float HP = 1 + m_Buffs.GetBuffTypeToValue(this, eBuffType.HP);
        float AddUnitCount = m_Buffs.GetBuffTypeToValue(this, eBuffType.AddUnitCount);
        float DamageRate = 1 + m_Buffs.GetBuffTypeToValue(this, eBuffType.DamageRate);
        float SkillDamageRate = 1 + m_Buffs.GetBuffTypeToValue(this, eBuffType.SkillDamageRate);
        float AttackRange = 1 + m_Buffs.GetBuffTypeToValue(this, eBuffType.AttackRange);
        float AttackSpeed = 1 + m_Buffs.GetBuffTypeToValue(this, eBuffType.AttackSpeed);
        float MoveSpeed = 1 + m_Buffs.GetBuffTypeToValue(this, eBuffType.MoveSpeed);
        float SkillCoolTime = m_Buffs.GetBuffTypeToValue(this, eBuffType.SkillCoolTime);
        float DamageReduction = m_Buffs.GetBuffTypeToValue(this, eBuffType.DamageReduction);
        
        m_BuffUnitData.Name = UnitData.Name;
        m_BuffUnitData.Level = UnitData.Level;
        m_BuffUnitData.Grade = UnitData.Grade;
        m_BuffUnitData.SP = UnitData.SP;
        m_BuffUnitData.LP = UnitData.LP;
        m_BuffUnitData.UnitColors = UnitData.UnitColors;
        m_BuffUnitData.Weapon = UnitData.Weapon;
        m_BuffUnitData.AP = UnitData.AP * AP;
        m_BuffUnitData.HP = UnitData.HP * HP;
        m_BuffUnitData.AddUnitCount = UnitData.AddUnitCount + (int)AddUnitCount;
        m_BuffUnitData.DamageRate = UnitData.DamageRate * DamageRate;
        m_BuffUnitData.SkillDamageRate = UnitData.SkillDamageRate * SkillDamageRate;
        m_BuffUnitData.AttackRange = UnitData.AttackRange * AttackRange;
        m_BuffUnitData.AttackSpeed = UnitData.AttackSpeed * AttackSpeed;
        m_BuffUnitData.MoveSpeed = UnitData.MoveSpeed * MoveSpeed;
        m_BuffUnitData.SkillCoolTime = SkillCoolTime;
        m_BuffUnitData.DamageReduction = DamageReduction;
        m_BuffUnitData.AttackSkill = UnitData.AttackSkill;
    }

    private void SetStatus(bool resetHP = true)
    {
        AP = m_BuffUnitData.Attack;
        if (AP < 1) AP = 1;
        MaxHP = m_BuffUnitData.Health;
        if (MaxHP < 1) MaxHP = 1;
        if (resetHP)
            HP = MaxHP;
        DamageRate = m_BuffUnitData.DamageRate;
    }

    void Update()
    {
        if (IsDie)
            return;
        if (HP < 0)
        {
            UnitState = eUnitStateType.Die;
            return;
        }

        if (m_Target == null)
        {
            m_Animator.Play("Idle");
        }
        else if (UnitState < eUnitStateType.Hiting)
        {
            if (InByUnitToAttackRange())
            {
                if (AttackSkill.isCoolTime && UnitState != eUnitStateType.Attacking)
                {
                    m_Animator.Play("Attack_" + UnitData.Weapon.ToString());
                    UnitState = eUnitStateType.Attacking;
                }

                if (UnitState != eUnitStateType.Attacking)
                {
                    for (int i = 0; i < SkillList.Count; i++)
                    {
                        if (SkillList[i] != null && SkillList[i].Data.SkillType == eSkillType.Active &&
                            (SkillList[i] as ActiveSkill).isCoolTime)
                            SkillList[i].Active(this, m_Target);
                    }
                }
                //Attack();
            }
            else
            {
                Move(m_BuffUnitData.MoveSpeed);
            }
        }

        float attackSpeed = m_BuffUnitData.AttackSpeed > 5 ? 5 : m_BuffUnitData.AttackSpeed;
        AttackSkill.CoolTime -= attackSpeed * Time.deltaTime;
        for (int i = 0; i < SkillList.Count; i++)
        {
            if (SkillList[i] != null)
                SkillList[i].CoolTime -= Time.deltaTime;
        }

        for (int i = 0; i < m_Buffs.Count; i++)
        {
            if(m_Buffs[i].IsApply && (m_Buffs[i].MaxDuration == 0 || m_Buffs[i].Duration > 0))
            {
                m_Buffs[i].Duration -= Time.deltaTime;
                if(m_Buffs[i].TickDown(this))
                {
                    BuffDataUpdate();
                }
            }

            if(m_Buffs[i].CoolTime > 0)
                m_Buffs[i].CoolTime -= Time.deltaTime;
        }
    }

    //�̵�
    public virtual void Move(float speed)
    {
        if (UnitState < eUnitStateType.Hiting && UnitState != eUnitStateType.Attacking && UnitState != eUnitStateType.Skilling)
        {
            if (UnitState != eUnitStateType.Move)
            {
                m_Animator.Play("Move");
                UnitState = eUnitStateType.Move;
            }

            Quaternion temp = Quaternion.LookRotation(transform.position - m_Target.transform.position);
            transform.rotation = Quaternion.Euler(0, temp.eulerAngles.y, 0);

            transform.Translate(Vector3.back * Time.deltaTime * speed); //����
        }
    }

    protected virtual bool InByUnitToAttackRange()
    {
        RaycastHit[] hits;
        int layerMask = 0;
        if(isEnemy)
            layerMask = LayerMask.GetMask("Unit", "Obstacle");
        else
            layerMask = LayerMask.GetMask("Enemy", "Obstacle");

        hits = Physics.RaycastAll(transform.position, -transform.forward, m_BuffUnitData.AttackRange, layerMask);
        //Debug.DrawRay(transform.position, -transform.forward * m_BuffUnitData.AttackRange, Color.red, 0.1f);
        //if (Physics.Raycast(transform.position, -transform.forward, out hit, Data.AttackRange))
        if (hits.Length > 0)
        {
            for (int i = 0; i < hits.Length; i++)
            {
                Unit unit = hits[i].transform.GetComponent<Unit>();
                if (unit != null && isEnemy != unit.isEnemy)
                {
                    return true;
                }
            }
        }
        return false;
    }

    //����
    public virtual void Attack()
    {
        if (m_Target != null)
        {
            AttackSkill.Active(this, m_Target);
            UnitState = eUnitStateType.Attack;
            //�̻��� ������ ��������.
            //Ȱ, ��, â?, ��Ŀ, ��, ����
        }
    }

    //�ǰ�
    public virtual void Hit(Damage damage)
    {
        if (!IsDie)
        {
            UnitState = eUnitStateType.Hit;
            //ActiveSkillOperate(damage.Unit);

            //Job.Hit(damage);
            float DamageReduction = m_BuffUnitData.DamageReduction;
            if (DamageReduction >= 0.95f)
                DamageReduction = 0.95f;
            float damagePoint = damage.DamagePoint * (1f - DamageReduction);
            HP -= damagePoint;
            float hp = (float)HP / (float)MaxHP;

            CalculateDamageMeter(damage);

            if (m_StateUI != null)
                m_StateUI.SetHP(hp);
            //m_StateUI.Hit(damage.Damage);
            if (HP <= 0)
            {
                Die(damage.Unit);
            }
            else
            {
                m_Animator.Play("Hit");
            }
        }
    }

    public void CalculateDamageMeter(Damage damage)
    {
        float DamageReduction = m_BuffUnitData.DamageReduction;
        float damagePoint = damage.DamagePoint * (1f - DamageReduction);
        float damageReduction = damage.DamagePoint * DamageReduction;

        if(damage.Unit.UnitType == eTargetType.Hero)
            damage.Unit.SaveDamageStats.Damage += damagePoint;
        else
            damage.Unit.Hero.SaveDamageStats.Damage += damagePoint;

        if (UnitType == eTargetType.Hero)
        {
            SaveDamageStats.DamageDealt += damagePoint;
            SaveDamageStats.DamageReduced += damageReduction;
        }
        else
        {
            Hero.SaveDamageStats.DamageDealt += damagePoint;
            Hero.SaveDamageStats.DamageReduced += damageReduction;
        }
    }

    //����
    public virtual void Die(Unit unit)
    {
        if (unit != null)
        {
            unit.Kill(this);
        }

        m_Animator.Play("Die");
        gameObject.DisableCollider();

        UnitState = eUnitStateType.Dieing;
        m_StateUI.SetDisable();

        DelayAction(0.5f, () =>
        {
            m_RootObj.SetActive(false);
            UnitState = eUnitStateType.Die;
        });
        //ActiveSkillOperate(unit);
    }
    //����
    public virtual void Kill(Unit unit)
    {
        //���� ���� ��� �ߵ��ϴ� ��ų �ߵ���
        UnitState = eUnitStateType.Kill;
    }

    public virtual void Resurrection()
    {
        DelayAction(1, () =>
        {
            if (HP > 1)
            {
                m_UnitState = eUnitStateType.None;
                m_RootObj.SetActive(true);
                gameObject.EnableCollider();
            }
        });
    }


    protected virtual void DelayAction(float delay, Action action)
    {
        if (gameObject.activeSelf)
        {
            StartCoroutine(DelayActionHandler(delay, action));
        }
    }

    protected IEnumerator DelayActionHandler(float delay, Action action)
    {
        if (delay != 0)
            yield return new WaitForSeconds(delay);

        if (action != null)
        {
            action();
        }
    }

    private void ApplyBuff()
    {
        bool isApply = false;
        for (int i = 0; i < m_Buffs.Count; i++)
        {
            isApply |= m_Buffs[i].Apply(this); 
        }

        if(isApply)
        {
            BuffDataUpdate();
        }
    }

    public void AddBuff(List<BuffData> buff, bool isInit = false)
    {
        m_Buffs.AddRange(buff);
        ApplyBuff();
        SetStatus(isInit);
    }
    public void AddBuff(BuffData buff, bool isInit = false)
    {
        m_Buffs.Add(buff);
        ApplyBuff();
        SetStatus(isInit);
    }

    public void RemoveBuff(BuffData buff)
    {
        BuffData data = m_Buffs.Find(temp => temp.BuffName == buff.BuffName);
        m_Buffs.Remove(data);
    }

    public GameObject GetArrow()
    {
        return m_ArrowObjs[(int)UnitData.Weapon];
    }

    public void PlayAnimation(string animation)
    {
        m_Animator.Play(animation);
    }

    public void LevelUp(int level)
    {
        UnitData.Level += level;
        SetStatus();
    }
    public void AddUnit(int count)
    {
        UnitData.AddUnitCount += count;
        SetStatus();
        BuffDataUpdate();
    }

    public void SetStateCoolBack(eUnitStateType type, Action action)
    {
        if (StateCoolBack.ContainsKey(type))
            StateCoolBack[type] += action;
        else
            StateCoolBack.Add(type, action);
    }

    public void RemoveStateCoolBack(eUnitStateType type, Action action)
    {

        if (StateCoolBack.ContainsKey(type))
            StateCoolBack[type] -= action;
    }
}
