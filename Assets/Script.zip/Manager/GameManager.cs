using MyProjeckt;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum eGameFlowState
{
    MainMenu,
    StageStart,
    InBattle,
    BattleResult,
    StageClear,
    GameOver
}
public class GameManager : Singleton<GameManager>
{
    //AP �� ����Ǵ� ��ġ ����
    public float Ap = 2;

    //HP �� ����Ǵ� ��ġ ����
    public float Hp = 10;

    //SP �� ����Ǵ� ��ġ ����
    public float Sp = 1;

    //LP �� ����Ǵ� ��ġ ����
    public float Lp = 0.0125f;
    //LP�� ���� �Ǵ� �ּ� ��ġ
    public float LP_def = 0.25f;

    //������ ���� ������
    public float Level = 0.1f;

    //Ư���Ƿ� ���� ���� ����Ʈ
    public List<BuffData> Buffs = new List<BuffData>();
    //���� ī�� -> �ܹ߼� + 1ȸ�� �� �پ��ϰ� ���� �� ����.
    public List<CardData> Cards = new List<CardData>();

    private eGameFlowState m_eGameFlowState = eGameFlowState.MainMenu;
    public eGameFlowState eGameFlowState
    {
        get
        {
            return m_eGameFlowState;
        }

        set
        {
            switch(value)
            {
                case eGameFlowState.MainMenu:
                    Buffs.Clear();
                    //Ư���� ���� ����
                    //Buffs.AddRange(MyInfoManager.Instance.BuffList);
                    break;
                case eGameFlowState.StageStart:
                    UnitManager.Instance.InitMyUnit();
                    eGameFlowState = eGameFlowState.InBattle;
                    return;
                case eGameFlowState.InBattle:
                    GameStart(StageIndex);
                    break;
                case eGameFlowState.BattleResult:
                    UnitManager.Instance.Restore();
                    StageIndex++;
                    WindowManager.Instance.Open(WindowIds.BattleResult_Window);
                    //�¸� �˾� + ����� �� ��/��ŷ/�� ���� window
                    break;
                case eGameFlowState.StageClear:
                    break;
                case eGameFlowState.GameOver:
                    WindowManager.Instance.Open(WindowIds.GameOver_Window);
                    
                    break;
            }
            m_eGameFlowState = value;
        }
    }

    public int StageIndex = 10;
    // Start is called before the first frame update
    void Start()
    {
        if (MyInfoManager.Instance.HeroSaveDatas.Count == 0)
        {
            MyInfoManager.Instance.HeroSaveDatas.Add(Gacha().GetSaveData());
        }

        //m_eGameFlowState = eGameFlowState.MainMenu;
        //eGameFlowState = eGameFlowState.StageStart;
        //���̺� ���� �ε�
        //���� ���� �ε�
        //�ʱ� ȭ�� ����
    }

    public void GameStart()
    {
        StageIndex = 1;
        eGameFlowState = eGameFlowState.StageStart;
    }

    public void Quit()
    {
        Application.Quit();
    }

    private void GameStart(int stageIndex)
    {
        Buffs.Clear();
        EconomyManager.Instance.ClearEconomyData();
        for (int i = 0; i < Cards.Count; i++)
        {
            Cards[i].Apply();
        }

        UnitManager.Instance.RegisterMyUnit();
        UnitManager.Instance.InitEnemyUnit(stageIndex);

        UIManager.Instance.InitUnitView();
    }

    //�������� �¸�
    public void GameWin()
    {
        EconomyManager.Instance.StageClear(StageIndex);
        eGameFlowState = eGameFlowState.BattleResult;
        //GameStart(StageIndex);
        //GameStart(StageIndex);
    }

    //�������� �й�
    public void GameOver()
    {
        UnitManager.Instance.Restore();
    }

    #region ġƮ�� �Լ�
    public UnitData Gacha()
    {
        return UnitRandomMachine.NewUnitData();
    }

    public void ChangeUnit()
    {
        UnitManager.Instance.Restore();
        int index = Random.Range(0, Table.NameTables.Length);
        MyInfoManager.Instance.HeroSaveDatas.Clear();

        MyInfoManager.Instance.HeroSaveDatas.Add(Gacha().GetSaveData());

        UnitManager.Instance.InitMyUnit();
        GameStart();
    }

    public void AddUnit()
    {
        if (MyInfoManager.Instance.HeroSaveDatas.Count < 5)
        {
            UnitManager.Instance.Restore();
            MyInfoManager.Instance.HeroSaveDatas.Add(Gacha().GetSaveData());
            eGameFlowState = eGameFlowState.StageStart;
        }
    }

    public void X2()
    {
        Time.timeScale = Time.timeScale == 1 ? 10 : 1;
    }
    #endregion
}
